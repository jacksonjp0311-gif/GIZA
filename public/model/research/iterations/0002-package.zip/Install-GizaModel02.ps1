param(
    [Parameter(Mandatory = $true)]
    [string]$ArcheonRoot
)

$ErrorActionPreference = 'Stop'
$ProjectName = 'giza-khafre-reverse-engineering'
$Source = (Resolve-Path $PSScriptRoot).Path
$Repo = (Resolve-Path $ArcheonRoot).Path
$Cargo = Join-Path $Repo 'Cargo.toml'
$Projects = Join-Path $Repo 'projects'
$Target = Join-Path $Projects $ProjectName

if (-not (Test-Path $Cargo)) { throw "ARCHEON root not detected: Cargo.toml missing at $Repo" }
if (-not (Test-Path $Projects)) { New-Item -ItemType Directory -Path $Projects -Force | Out-Null }

$SourceNorm = [IO.Path]::GetFullPath($Source).TrimEnd('\\')
$TargetNorm = [IO.Path]::GetFullPath($Target).TrimEnd('\\')
if ($SourceNorm -ne $TargetNorm) {
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force
    }
}

$Required = @('project.json','assemblies.json','parts.json','requirements.json','parameters.json','provenance.json','cad\\khafre_pyramid_preview.stl','cad\\helix_access_preview.stl')
$Required | ForEach-Object {
    $Path = Join-Path $Target $_
    if (-not (Test-Path $Path)) { throw "Model validation failed. Missing: $Path" }
}
@('project.json','assemblies.json','parts.json','requirements.json','parameters.json','provenance.json') | ForEach-Object {
    Get-Content (Join-Path $Target $_) -Raw | ConvertFrom-Json | Out-Null
}
Write-Host "ARCHEON Model 02 rev.0002 copied to: $Target"
Write-Host "No git add, commit, or push was performed."
