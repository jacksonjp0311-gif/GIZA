# Test plan — rev.0002

## Gate 0 — geometry existence
Before assigning a function to the controversial deep geometry, seek independent recovery of the same coordinates with methods that do not share the same inversion assumptions: microgravity, seismic methods, resistivity where appropriate, and muography where geometry permits.

## Gate 1 — topology
If boundaries replicate, test whether shafts, helices, connectors and terminals are actually continuous. Disconnected anomalies cannot support transport/hydraulic interpretations.

## Gate 2 — function discrimination
Score each hypothesis only on preregistered signatures:

- access/transport: traversable clearances, junctions, construction interfaces;
- hydraulic: connected head source/sink, flow wear/mineralization, hydraulic continuity;
- resonant: mode localization and statistically unusual geometry sensitivity;
- magnetic/plasma: field source/topology, ionization/input, confinement/coupling, losses, thermal path, extraction path.

## Gate 3 — perturbation
Vary pyramid slope, chamber coordinates, material dielectric properties and all unverified deep dimensions. Report sensitivity and confidence intervals, not a single best-looking configuration.

## Gate 4 — promotion
No hypothesis changes from HYPOTHESIS to SUPPORTED without independent evidence. Simulation output is SIMULATED evidence only.
