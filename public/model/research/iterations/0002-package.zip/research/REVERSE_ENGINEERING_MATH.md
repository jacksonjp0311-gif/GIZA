# Reverse-engineering mathematics — rev.0002

## Epistemic rule

Geometry is not function. Every equation here either describes established surface/internal geometry or produces a **conditional prediction** from an unverified hypothesis.

## Surface monument

For a square pyramid with base side `b` and height `h`:

`V = b² h / 3`

Using `b = 215.25 m`, `h = 143.5 m` gives `V ≈ 2,216,241 m³` as an ideal geometric envelope, not masonry volume after passages/voids.

## Deep-shaft conditional model

For shaft radius `r` and depth `L`:

`V_shaft = π r² L`

With the rev.0002 modeling assumptions, one shaft envelope is `61,581 m³`. This does **not** imply the shaft exists.

## Geophysical testability

A first-order point-mass gravity screen is

`Δg ≈ G ΔM / d²`, `ΔM = Δρ V`.

A representative 80 m cube-shaped void at 648 m with full limestone-to-air contrast gives about `21.2 µGal` directly above its center in the point-mass approximation. A real forward model must use finite prisms, lateral offsets, topography, regional geology and instrument noise.

## Hydrostatic scale

`P = ρ g h`. For a connected 648 m water column, `P ≈ 6.36 MPa`. This is stored energy/head, not an energy source.

## Acoustic scale

An ideal two-ended column baseline is `f_n = n c/(2L)`. For 648 m, air fundamental ≈ `0.2647 Hz`; water ≈ `1.1420 Hz`. Real boundary conditions must be solved before interpretation.

## Magnetic/plasma gate

Single-particle gyro-radius:

`r_L = m v_perp / (|q| B)`

This gives a **necessary-not-sufficient** magnetic scale. Confinement additionally requires field topology, plasma pressure/beta, ionization input, stability, losses, thermal handling and an energy extraction mechanism. See `results/rev0002_plasma_field_sweep.csv`.

## Optimization/falsification

For any proposed resonant function define a preregistered objective `J(g,m)` over geometry `g` and material model `m`. Then perturb the actual geometry:

`g' = g + δg`

and compare `J(g)` against a null ensemble `{J(g'_i)}`. A claimed optimum is interesting only if it survives parameter uncertainty, multiple-objective correction and independent solver/measurement replication.
