# ARCHEON Model 02 — Giza / Khafre Reverse Engineering

**Current revision: rev.0002**

This folder is a canonical ARCHEON project for iterative, falsifiable reverse engineering of the Pyramid of Khafre. It deliberately keeps three layers separate:

1. **Surface/context geometry** — published monument dimensions rendered as a concept envelope.
2. **Established internal topology** — the two entrance systems, subsidiary chamber branch, burial chamber and sarcophagus, encoded as `DERIVED` 3-D envelopes until survey-grade CAD is imported.
3. **Controversial deep geometry** — five upper structures, eight shafts, helices, connectors and two terminal volumes kept `UNVERIFIED`.

## Why rev.0002 matters

rev.0001 made the speculative geometry explodable. rev.0002 adds the control case: **what is actually known inside Khafre**. This prevents the deep claim from visually swallowing the established architecture and gives every future hypothesis a common coordinate/evidence frame.

## ARCHEON compatibility

The project follows ARCHEON's split-file DesignIR convention:

- `project.json`
- `requirements.json`
- `assemblies.json`
- `parts.json`
- `interfaces.json`
- `features.json`
- `materials.json`
- `parameters.json`
- `provenance.json`

Additional reverse-engineering files live under `research/` and are ignored by the core loader.

The existing workstation can use semantic assemblies for select / isolate / section / provenance / explosion. No renderer fork is required for the model.

## Truth contract

- `SOURCE` — source statement or dimension.
- `DERIVED` — geometry/calculation reconstructed from sources or model relationships.
- `ASSUMED` — explicit modeling choice.
- `UNVERIFIED` — public claim not independently established.
- `SIMULATED` — numerical result only.

**Visual complexity never upgrades provenance.**

## rev.0002 assemblies

- `asm.surface` — plateau reference and Khafre envelope.
- `asm.known_internal` — established internal architecture.
- `asm.upper` — unverified near-base claimed structures.
- `asm.deep.alpha` / `asm.deep.beta` — unverified 4+4 shaft/helix arrays.
- `asm.terminals` — unverified terminal volumes.

## Quantitative baselines

See `research/REVERSE_ENGINEERING_MATH.md`, `research/predictions.json`, and `research/results/`. rev.0002 adds:

- microgravity screening for representative deep voids;
- ideal acoustic column and burial-chamber mode baselines;
- a hydrogen-ion gyroradius field sweep for the magnetic/plasma hypothesis;
- an explicit perturbation/falsification protocol.

These are **tests of hypotheses**, not evidence for them.

## Run the deterministic baseline

```powershell
python .\research\run_rev0002.py
```

## Install locally into ARCHEON

The installer only copies the model. It does **not** commit or push.

```powershell
.\Install-GizaModel02.ps1 -ArcheonRoot "C:\path\to\ARCHEON"
```

Then select `Giza / Khafre Reverse Engineering` from ARCHEON's project selector.

## Iteration discipline

Every revision must preserve the prior package under `research/iterations/`, update the provenance/evidence ledger, state all assumptions, generate predictions before interpretation, and preserve falsifiers.

## rev.0003 target

Replace the current approximate known-interior envelopes with a survey-plan-derived coordinate model; add geometry perturbation hooks and a proper finite-prism gravity forward model. Do not add more speculative machinery until those controls are in place.
