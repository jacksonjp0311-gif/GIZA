param(
    [Parameter(Mandatory = $true)]
    [string]$ArcheonRoot,
    [switch]$Commit,
    [switch]$Push
)

$ErrorActionPreference = 'Stop'
$ProjectName = 'giza-khafre-reverse-engineering'
$Source = (Resolve-Path $PSScriptRoot).Path
$Repo = (Resolve-Path $ArcheonRoot).Path
$Cargo = Join-Path $Repo 'Cargo.toml'
$Projects = Join-Path $Repo 'projects'
$Target = Join-Path $Projects $ProjectName

if (-not (Test-Path $Cargo)) {
    throw "ARCHEON root not detected: Cargo.toml missing at $Repo"
}

if (-not (Test-Path $Projects)) {
    New-Item -ItemType Directory -Path $Projects -Force | Out-Null
}

$SourceNorm = [IO.Path]::GetFullPath($Source).TrimEnd('\')
$TargetNorm = [IO.Path]::GetFullPath($Target).TrimEnd('\')

if ($SourceNorm -ne $TargetNorm) {
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force
    }
}

if ($SourceNorm -eq $TargetNorm) {
    Write-Host "Model already located in ARCHEON/projects/$ProjectName"
}

$Required = @(
    'project.json',
    'assemblies.json',
    'parts.json',
    'cad\khafre_pyramid_preview.stl',
    'cad\helix_access_preview.stl'
)

$Required | ForEach-Object {
    $Path = Join-Path $Target $_
    if (-not (Test-Path $Path)) {
        throw "Model validation failed. Missing: $Path"
    }
}

Get-Content (Join-Path $Target 'project.json') -Raw | ConvertFrom-Json | Out-Null
Get-Content (Join-Path $Target 'assemblies.json') -Raw | ConvertFrom-Json | Out-Null
Get-Content (Join-Path $Target 'parts.json') -Raw | ConvertFrom-Json | Out-Null

Write-Host ""
Write-Host "ARCHEON Model 02 installed:"
Write-Host "  $Target"
Write-Host ""
git -C $Repo status --short -- "projects/$ProjectName"

if ($Commit) {
    git -C $Repo add -- "projects/$ProjectName"
    git -C $Repo commit -m "Add ARCHEON Model 02 Giza reverse-engineering project"
}

if ($Push) {
    git -C $Repo push
}
