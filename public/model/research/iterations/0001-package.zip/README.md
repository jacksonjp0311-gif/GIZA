# ARCHEON Model 02 — Giza / Khafre Reverse Engineering

This folder is the canonical ARCHEON project for iterative reverse engineering of the Pyramid of Khafre and the controversial reported deep-structure geometry beneath it.

## Truth contract

This project deliberately separates **observed / source-derived monument geometry** from **unverified reported subsurface geometry**.

- `DERIVED` — generated preview based on published or conventional dimensions/context.
- `UNVERIFIED` — geometry included because it was publicly claimed, not because it has been independently measured.
- `ASSUMED` — modeling choices introduced only to make a hypothesis computationally testable.
- `SIMULATED` — future numerical output; never archaeological evidence by itself.

**The eight shafts, spiral paths, connectors, and two terminal volumes in this revision are NOT asserted as archaeological fact.**

## Coordinate frame

ARCHEON engineering world:

- units: metres
- right-handed
- Z-up
- plateau reference surface: `z = 0`

## Assemblies

1. `asm.surface` — plateau reference + Khafre pyramid envelope.
2. `asm.upper` — five reported near-base structures.
3. `asm.deep.alpha` — four reported shafts + helical paths + conceptual connectors.
4. `asm.deep.beta` — mirrored four-channel array.
5. `asm.terminals` — two reported ~80 m cube-like terminal volumes.

The existing ARCHEON workstation can select, isolate, section, x-ray, provenance-color and explode these semantic groups.

## Reverse-engineering mathematics

Pyramid volume:

`V_pyr = b^2 h / 3`

A cylindrical deep shaft:

`V_shaft = pi r^2 L`

Approximate lithostatic stress at depth `h`:

`sigma_v ≈ rho_rock g h`

Hydrostatic head if a connected shaft were water-filled:

`P = rho_water g h`

Long-column acoustic scale:

`f_n ≈ n c / (2L)` for a two-ended idealized mode, with boundary conditions changed as required.

A rectangular cavity eigenfrequency test can begin from:

`f_mnp = c/(2 sqrt(epsilon_r)) * sqrt((m/a)^2 + (n/b)^2 + (p/d)^2)`

For a magnetic/plasma interpretation, a minimum physics audit must include field generation, confinement and power balance rather than geometry alone. Useful first checks include:

`r_L = m v_perp / (|q| B)`

`beta = 2 mu_0 p / B^2`

No plasma hypothesis survives unless a physically credible `B` field source, energy input, thermal path and extraction path can be identified.

## Iteration protocol

Every revision stays in this folder. Each iteration must:

1. freeze the current geometry and parameter ledger;
2. state which dimensions are SOURCE / DERIVED / ASSUMED / UNVERIFIED;
3. generate one or more quantitative predictions;
4. perturb the geometry and compare against controls;
5. record falsifiers before interpreting results;
6. preserve the prior iteration under `research/iterations/`.

See `research/hypotheses.json` and `research/model_parameters.json`.

## Revision 0001 goal

Build the semantic 3-D component model first. Do **not** promote an energy interpretation yet. The next revision should add measured internal Khafre substructure, evidence-linked dimensions, and computational perturbation sweeps.


## UI preview

Open `ui-preview.html` for the Revision 0001 spatial-workstation concept. The production ARCHEON workstation remains the target renderer; this preview simply freezes the intended evidence-layer and analysis-panel layout for iteration review.

## Sources used for Revision 0001

- Egyptian Ministry of Tourism and Antiquities, Pyramid Complex of Khafre: https://egymonuments.gov.eg/en/monuments/pyramid-complex-of-khafre-khefren
- Ahram Online summary of the 2025 deep-structure claims and 2026 methodological controversy: https://english.ahram.org.eg/NewsContentP/50/544236/AlAhram-Weekly/Controversy-over-Pyramid-claims.aspx
- Digital Giza / Harvard Giza Project for established site context and future reference geometry: https://giza.fas.harvard.edu/giza3d/

These sources do not validate the deep-structure claim. They are separated by provenance status in the model.
